#define F_CPU 16000000UL
#include "funsape/funsapeLibGlobalDefines.hpp"
#include "funsape/peripheral/funsapeLibUsart0.hpp"
#include <util/delay.h>
#include <avr/interrupt.h>

// Pinos para botões
#define BTN_UP_PIN    PD2
#define BTN_DOWN_PIN  PD3
#define BTN_LEFT_PIN  PD4
#define BTN_RIGHT_PIN PD5

// Pino para IRQ simulado (conectado ao PD2 do receptor)
#define IRQ_SIM_PIN   PB0

// Comandos NRF24 simulados
#define R_REGISTER    0x00
#define W_REGISTER    0x20
#define R_RX_PAYLOAD  0x61
#define STATUS_REG    0x07

// Botões NES
#define BTN_UP     0x10
#define BTN_DOWN   0x20
#define BTN_LEFT   0x40
#define BTN_RIGHT  0x80

// Variáveis globais
volatile uint8_t current_command = 0;
volatile uint8_t status_reg = 0x00;
volatile uint8_t rx_payload = 0x00;
volatile uint8_t last_spi_cmd = 0x00;
volatile uint8_t spi_activity = 0;

// Inicialização dos botões
void buttons_init(void) {
    // Configurar pinos dos botões como entrada com pull-up
    DDRD &= ~((1 << BTN_UP_PIN) | (1 << BTN_DOWN_PIN) |
              (1 << BTN_LEFT_PIN) | (1 << BTN_RIGHT_PIN));
    PORTD |= (1 << BTN_UP_PIN) | (1 << BTN_DOWN_PIN) |
             (1 << BTN_LEFT_PIN) | (1 << BTN_RIGHT_PIN);
}

// Inicialização do IRQ simulado
void irq_sim_init(void) {
    DDRB |= (1 << IRQ_SIM_PIN);    // Saída
    PORTB |= (1 << IRQ_SIM_PIN);   // Inicialmente alto (sem IRQ)
}

// Gerar IRQ (borda de descida)
void generate_irq(void) {
    // printf("[IRQ] Generating interrupt...\r\n");
    PORTB &= ~(1 << IRQ_SIM_PIN);  // IRQ baixo
    _delay_us(100);
    PORTB |= (1 << IRQ_SIM_PIN);   // IRQ alto novamente
    // printf("[IRQ] Interrupt completed\r\n");
}

// Inicialização SPI como escravo - CORREÇÃO CRÍTICA
void spi_slave_init(void) {
    // Configurar MISO como saída, MOSI, SCK e CSN como entrada
    DDRB &= ~(1 << PB4);
    // PB2 (CSN), PB3 (MOSI), PB5 (SCK) como entradas

    // Ativar pull-ups nas entradas
    PORTB |= (1 << PB2) | (1 << PB3) | (1 << PB5);

    // Configurar SPI como escravo
    SPCR = (1 << SPE) | (1 << SPIE); // SPI Enable, SPI Interrupt Enable
    SPSR = 0; // Limpar flags

    // printf("[SPI] Slave configured - waiting for master...\r\n");
}

// Ler botões e atualizar comando
uint8_t read_buttons(void) {
    uint8_t command = 0;

    // Lógica invertida (pull-up -> 0 quando pressionado)
    if (!(PIND & (1 << BTN_UP_PIN)))    command |= BTN_UP;
    if (!(PIND & (1 << BTN_DOWN_PIN)))  command |= BTN_DOWN;
    if (!(PIND & (1 << BTN_LEFT_PIN)))  command |= BTN_LEFT;
    if (!(PIND & (1 << BTN_RIGHT_PIN))) command |= BTN_RIGHT;

    return command;
}

int main(void) {
    // Inicializações
    usart0.setBaudRate(Usart0::BaudRate::BAUD_RATE_57600);
    usart0.enableTransmitter();
    usart0.enableReceiver();
    usart0.stdio();

    printf("========================================\r\n");
    printf("     NRF24 SIMULATOR - TRANSMITTER\r\n");
    printf("========================================\r\n");
    printf("UART configured at 57600 baud!\r\n");

    buttons_init();
    irq_sim_init();
    spi_slave_init();


    uint8_t last_command = 0xFF;
    uint8_t button_count = 0;

    printf("System initialized - waiting for buttons...\r\n\r\n");

    sei();

    while (1) {
        // Verificar atividade SPI
        if (spi_activity) {
            printf("[SPI] Activity detected - %d transactions\r\n", spi_activity);
            spi_activity = 0;
        }

        // Ler estado atual dos botões
        current_command = read_buttons();

        // Se o comando mudou
        if (current_command != last_command) {

            if (current_command != 0) {
                // Botão pressionado
                button_count++;
                rx_payload = current_command;
                status_reg = 0x40; // Flag RX_DR ativa

                printf("[BTN#%d] Pressed: 0x%02X - ", button_count, current_command);

                if (current_command & BTN_UP) printf("UP ");
                if (current_command & BTN_DOWN) printf("DOWN ");
                if (current_command & BTN_LEFT) printf("LEFT ");
                if (current_command & BTN_RIGHT) printf("RIGHT ");
                printf("\r\n");

                printf("[TX] Setting payload=0x%02X, status=0x%02X\r\n",
                       rx_payload, status_reg);

                generate_irq();

                printf("[LED] Status LED toggled\r\n\r\n");

            } else {
                // Botão solto
                printf("[BTN] All buttons released\r\n");
                status_reg = 0x00;
                printf("[TX] Status cleared to 0x00\r\n\r\n");
            }

            last_command = current_command;
        }

        _delay_ms(20);
    }

    return 0;
}

// Interrupção do SPI - CORREÇÃO SIMPLIFICADA
ISR(SPI_STC_vect) {
    uint8_t received_data = SPDR;
    spi_activity++;


    // Lógica simplificada e robusta
    switch (received_data) {
        case 0x07: // R_REGISTER | STATUS_REG
            SPDR = status_reg;
            last_spi_cmd = 0x07;
            break;

        case R_RX_PAYLOAD:
            SPDR = rx_payload;
            // Limpar após leitura (simula comportamento real)
            status_reg = 0x00;
            rx_payload = 0x00;
            last_spi_cmd = R_RX_PAYLOAD;
            break;

        case 0xFF: // NOP
            if (last_spi_cmd == 0x07) {
                SPDR = status_reg; // Continua retornando STATUS
            } else {
                SPDR = 0x00;
            }
            break;

        default:
            SPDR = 0x00;
            last_spi_cmd = received_data;
            break;
    }
}
