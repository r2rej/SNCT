#define F_CPU 16000000UL
#include "funsape/funsapeLibGlobalDefines.hpp"
#include "funsape/peripheral/funsapeLibUsart0.hpp"
#include "funsape/util/funsapeLibCircularBuffer.hpp"
#include "nrf24.hpp"

// #include "include/nrf24.h"
// Definições dos pinos - NRF24L01
#define CE_PIN  PB0
#define CSN_PIN PB1

#define BUTTON_DIR		DDRB
#define BUTTON_OUT		PORTB
#define BUTTON_IN		PINB
#define BUTTON_A		PB2
#define BUTTON_B		PB3
#define BUTTON_C		PB4

#define MOTOR_DIR		DDRC
#define MOTOR_OUT		PORTC
#define MOTOR_IN1		PC0
#define MOTOR_IN2		PC1
#define MOTOR_IN3		PC2
#define MOTOR_IN4		PC3

#define MOTOR_EN_DIR	DDRD
#define MOTOR_EN_OUT	PORD
#define MOTOR_ENA		PD5
#define MOTOR_ENB		PD6


#define INIT	0x7E	//0x7E
#define DATA	0x40	//0x40
#define CALIB	0x3F	//0x3F
#define NOPC	0x00	//0x00

typedef struct {
    uint8_t joyX_min;
    uint8_t joyX_center;
    uint8_t joyX_max;
    uint8_t joyY_min;
    uint8_t joyY_center;
    uint8_t joyY_max;
} calibration_data_t;

// Variável global de calibração
calibration_data_t calib_data = {
    .joyX_min = 0,
    .joyX_center = 127,
    .joyX_max = 255,
    .joyY_min = 0,
    .joyY_center = 127,
    .joyY_max = 255
};


typedef enum {
    MOV_STOP = 0,
    MOV_FORWARD,           // Ambos motores para frente
    MOV_BACKWARD,          // Ambos motores para trás
    MOV_TURN_LEFT,         // Giro no eixo: esq trás, dir frente
    MOV_TURN_RIGHT,        // Giro no eixo: esq frente, dir trás
    MOV_FORWARD_LEFT,      // Curva suave: dir frente, esq parado
    MOV_FORWARD_RIGHT,     // Curva suave: esq frente, dir parado
    MOV_BACKWARD_LEFT,     // Curva ré: dir trás, esq parado
    MOV_BACKWARD_RIGHT,    // Curva ré: esq trás, dir parado

} movement_t;

CircularBuffer<uint8_t> nrfRxCircBuffer;

// Variáveis globais
vbool_t gettingPackage = true;
vbool_t newPackageAwaiting = false;
uint8_t packageData[8];
uint8_t packageIndex = 0;

void process_data_package(uint8_t *data);
void process_calib_package(uint8_t *data);
int8_t map_int8(uint8_t x, uint8_t in_min, uint8_t in_max, int8_t out_min, int8_t out_max);
int8_t constrain_int8(int8_t x, int8_t min_val, int8_t max_val);
void set_motors(uint8_t left_dir, uint8_t right_dir);
void movement(movement_t mov);
void motor_left_speed(uint8_t speed);
void motor_right_speed(uint8_t speed);
void pwm_init(void);
void set_motors_speed(int16_t left_speed, int16_t right_speed);

// Função para mapear valores de uma faixa para outra (retorna int8_t)
int8_t map_int8(uint8_t x, uint8_t in_min, uint8_t in_max, int8_t out_min, int8_t out_max) {
    return (int8_t)((x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min);
}

// Função para limitar valores int8_t entre mínimo e máximo
int8_t constrain_int8(int8_t x, int8_t min_val, int8_t max_val) {
    if (x < min_val) return min_val;
    if (x > max_val) return max_val;
    return x;
}
// Controle dos motores (ponte H)
void set_motors(uint8_t left_dir, uint8_t right_dir) {
    // Motor A (esquerdo)
    if(left_dir == 1) { // Frente
        MOTOR_OUT |= (1 << MOTOR_IN1);
        MOTOR_OUT &= ~(1 << MOTOR_IN2);
    }
    else if(left_dir == 2) { // Trás
        MOTOR_OUT &= ~(1 << MOTOR_IN1);
        MOTOR_OUT |= (1 << MOTOR_IN2);
    }
    else { // Parar
        MOTOR_OUT &= ~((1 << MOTOR_IN1) | (1 << MOTOR_IN2));
        // Desabilita o motor A
    }

    // Motor B (direito)
    if(right_dir == 1) { // Frente
        MOTOR_OUT |= (1 << MOTOR_IN3);
        MOTOR_OUT &= ~(1 << MOTOR_IN4);
    }
    else if(right_dir == 2) { // Trás
        MOTOR_OUT &= ~(1 << MOTOR_IN3);
        MOTOR_OUT |= (1 << MOTOR_IN4);
    }
    else { // Parar
        MOTOR_OUT &= ~((1 << MOTOR_IN3) | (1 << MOTOR_IN4));
    }
}

// Função para controlar a velocidade dos motores com sinal
// Velocidade de -255 a 255 (negativo para trás, positivo para frente)


void movement(movement_t mov) {
    switch(mov) {
        case MOV_FORWARD:
            set_motors(1, 1); // Ambos para frente
            break;
        case MOV_BACKWARD:
            set_motors(2, 2); // Ambos para trás
            break;
        case MOV_TURN_LEFT:
            set_motors(2, 1); // Esquerdo trás, direito frente
            break;
        case MOV_TURN_RIGHT:
            set_motors(1, 2); // Esquerdo frente, direito trás
            break;
        case MOV_FORWARD_LEFT:
            set_motors(0, 1); // Apenas motor direito para frente
            break;
        case MOV_FORWARD_RIGHT:
            set_motors(1, 0); // Apenas motor esquerdo para frente
            break;
        case MOV_BACKWARD_LEFT:
            set_motors(0, 2); // Apenas motor direito para trás
            break;
        case MOV_BACKWARD_RIGHT:
            set_motors(2, 0); // Apenas motor esquerdo para trás
            break;
        default: // MOV_STOP
            set_motors(0, 0);
            break;
    }
}

void test_movements_simple() {
    // Configurar stdout para UART
    printf("Starting motor test sequence..\r\n");

    // Teste 1: Frente por 2 segundos
    printf("MOV_FORWARD - Both motors forward\r\n");
    movement(MOV_FORWARD);
    _delay_ms(2000);

    // Teste 2: Parar brevemente
    printf("MOV_STOP - Stopping\r\n");
    movement(MOV_STOP);
    _delay_ms(500);

    // Teste 3: Ré por 2 segundos
    printf("MOV_BACKWARD - Both motors backward\r\n");
    movement(MOV_BACKWARD);
    _delay_ms(2000);

    // Teste 4: Parar brevemente
    printf("MOV_STOP - Stopping\r\n");
    movement(MOV_STOP);
    _delay_ms(500);

    // Teste 5: Girar esquerda por 1 segundo
    printf("MOV_TURN_LEFT - Left motor backward, right motor forward\r\n");
    movement(MOV_TURN_LEFT);
    _delay_ms(1000);

    // Teste 6: Girar direita por 1 segundo
    printf("MOV_TURN_RIGHT - Left motor forward, right motor backward\r\n");
    movement(MOV_TURN_RIGHT);
    _delay_ms(1000);

    // Teste 7: Parar
    printf("MOV_STOP - Test sequence completed\r\n");
    movement(MOV_STOP);
}

void motor_left_speed(uint8_t speed) {
    OCR0A = speed;  // MOTOR_ENA está no pino PD6 (OC0A)
}

void motor_right_speed(uint8_t speed) {
    OCR0B = speed;  // MOTOR_ENB está no pino PD5 (OC0B)
}

void pwm_init(void) {
    // Configurar Timer0 para PWM nos pinos OC0A (PD6) e OC0B (PD5)

    TCCR0A = (1 << WGM00) | (1 << WGM01) | (1 << COM0A1) | (1 << COM0B1);
    TCCR0B = (1 << CS01);
}

void set_motors_speed(int16_t left_speed, int16_t right_speed) {
    // Motor esquerdo
    if (left_speed > 0) {
        // Frente
        MOTOR_OUT |= (1 << MOTOR_IN1);
        MOTOR_OUT &= ~(1 << MOTOR_IN2);
        motor_left_speed(left_speed);
    } else if (left_speed < 0) {
        // Trás
        MOTOR_OUT &= ~(1 << MOTOR_IN1);
        MOTOR_OUT |= (1 << MOTOR_IN2);
        motor_left_speed(-left_speed);
    } else {
        // Parar
        MOTOR_OUT &= ~((1 << MOTOR_IN1) | (1 << MOTOR_IN2));
        motor_left_speed(0);
    }

    // Motor direito
    if (right_speed > 0) {
        // Frente
        MOTOR_OUT |= (1 << MOTOR_IN3);
        MOTOR_OUT &= ~(1 << MOTOR_IN4);
        motor_right_speed(right_speed);
    } else if (right_speed < 0) {
        // Trás
        MOTOR_OUT &= ~(1 << MOTOR_IN3);
        MOTOR_OUT |= (1 << MOTOR_IN4);
        motor_right_speed(-right_speed);
    } else {
        // Parar
        MOTOR_OUT &= ~((1 << MOTOR_IN3) | (1 << MOTOR_IN4));
        motor_right_speed(0);
    }
}

// =============================================================================
// Controle direto de velocidade com int8_t e PWM ×2 - Apenas joystick
// =============================================================================

void process_data_package(uint8_t *data) {
    uint8_t joyX = data[2];
    uint8_t joyY = data[3];
    // Ignorar btnC e btnZ (data[4] e data[5])

    // Zonas mortas
    #define DEAD_ZONE 15
    #define CENTER 127

    // Converter valores do joystick para int8_t (-127 a 127)
    int8_t joyY_speed = 0;
    int8_t joyX_speed = 0;

    // Calcular velocidade Y (frente/ré)
    if (joyY > (CENTER + DEAD_ZONE)) {
        joyY_speed = map_int8(joyY, CENTER + DEAD_ZONE, 255, 0, 127);
        printf("COMANDO: FRENTE - Velocidade: %d\r\n", joyY_speed);
    } else if (joyY < (CENTER - DEAD_ZONE)) {
        joyY_speed = -map_int8(joyY, 0, CENTER - DEAD_ZONE, 0, 127);
        printf("COMANDO: RÉ - Velocidade: %d\r\n", -joyY_speed);
    }

    // Calcular velocidade X (curvas)
    if (joyX > (CENTER + DEAD_ZONE)) {
        joyX_speed = map_int8(joyX, CENTER + DEAD_ZONE, 255, 0, 127);
        printf("COMANDO: CURVA DIREITA - Intensidade: %d\r\n", joyX_speed);
    } else if (joyX < (CENTER - DEAD_ZONE)) {
        joyX_speed = -map_int8(joyX, 0, CENTER - DEAD_ZONE, 0, 127);
        printf("COMANDO: CURVA ESQUERDA - Intensidade: %d\r\n", -joyX_speed);
    }

    // Calcular velocidades dos motores (soma/subtração)
    int8_t left_speed = joyY_speed + joyX_speed;
    int8_t right_speed = joyY_speed - joyX_speed;

    // Limitar velocidades entre -127 e 127
    left_speed = constrain_int8(left_speed, -127, 127);
    right_speed = constrain_int8(right_speed, -127, 127);

    printf("MOTORES BRUTO - Esquerdo: %d, Direito: %d\r\n", left_speed, right_speed);

    // Converter para PWM (0-255) multiplicando por 2 em módulo
    uint8_t left_pwm = abs(left_speed) * 2;
    uint8_t right_pwm = abs(right_speed) * 2;

    printf("MOTORES PWM - Esquerdo: %u, Direito: %u\r\n", left_pwm, right_pwm);

    // Controlar motor esquerdo diretamente
    if (left_speed > 0) {
        // Frente
        MOTOR_OUT |= (1 << MOTOR_IN1);
        MOTOR_OUT &= ~(1 << MOTOR_IN2);
        motor_left_speed(left_pwm);
        printf("MOTOR ESQUERDO: FRENTE PWM %u\r\n", left_pwm);
    } else if (left_speed < 0) {
        // Ré
        MOTOR_OUT &= ~(1 << MOTOR_IN1);
        MOTOR_OUT |= (1 << MOTOR_IN2);
        motor_left_speed(left_pwm);
        printf("MOTOR ESQUERDO: RÉ PWM %u\r\n", left_pwm);
    } else {
        // Parado
        MOTOR_OUT &= ~((1 << MOTOR_IN1) | (1 << MOTOR_IN2));
        motor_left_speed(0);
        printf("MOTOR ESQUERDO: PARADO\r\n");
    }

    // Controlar motor direito diretamente
    if (right_speed > 0) {
        // Frente
        MOTOR_OUT |= (1 << MOTOR_IN3);
        MOTOR_OUT &= ~(1 << MOTOR_IN4);
        motor_right_speed(right_pwm);
        printf("MOTOR DIREITO: FRENTE PWM %u\r\n", right_pwm);
    } else if (right_speed < 0) {
        // Ré
        MOTOR_OUT &= ~(1 << MOTOR_IN3);
        MOTOR_OUT |= (1 << MOTOR_IN4);
        motor_right_speed(right_pwm);
        printf("MOTOR DIREITO: RÉ PWM %u\r\n", right_pwm);
    } else {
        // Parado
        MOTOR_OUT &= ~((1 << MOTOR_IN3) | (1 << MOTOR_IN4));
        motor_right_speed(0);
        printf("MOTOR DIREITO: PARADO\r\n");
    }

    // Debug - apenas dados do joystick
    printf("DADOS - JoyX: %u, JoyY: %u\r\n", joyX, joyY);
}

void process_calib_package(uint8_t *data) {
    printf("=== PROCESSANDO CALIBRACAO ===\r\n");

    // Extrair dados do pacote
    calib_data.joyX_min = data[2];
    calib_data.joyX_center = data[3];
    calib_data.joyX_max = data[4];
    calib_data.joyY_min = data[5];
    calib_data.joyY_center = data[6];
    calib_data.joyY_max = data[7];

    // Validar dados (garantir min < center < max)
    if (calib_data.joyX_min >= calib_data.joyX_center) {
        calib_data.joyX_center = (calib_data.joyX_min + 1) % 256;
        printf("AVISO: Ajustado center X para %u\r\n", calib_data.joyX_center);
    }
    if (calib_data.joyX_center >= calib_data.joyX_max) {
        calib_data.joyX_max = (calib_data.joyX_center + 1) % 256;
        printf("AVISO: Ajustado max X para %u\r\n", calib_data.joyX_max);
    }
    if (calib_data.joyY_min >= calib_data.joyY_center) {
        calib_data.joyY_center = (calib_data.joyY_min + 1) % 256;
        printf("AVISO: Ajustado center Y para %u\r\n", calib_data.joyY_center);
    }
    if (calib_data.joyY_center >= calib_data.joyY_max) {
        calib_data.joyY_max = (calib_data.joyY_center + 1) % 256;
        printf("AVISO: Ajustado max Y para %u\r\n", calib_data.joyY_max);
    }

    printf("CALIBRACAO CONCLUIDA:\r\n");
    printf("  Eixo X - Min: %u, Center: %u, Max: %u\r\n",
           calib_data.joyX_min, calib_data.joyX_center, calib_data.joyX_max);
    printf("  Eixo Y - Min: %u, Center: %u, Max: %u\r\n",
           calib_data.joyY_min, calib_data.joyY_center, calib_data.joyY_max);
    printf("=== FIM CALIBRACAO ===\r\n");

    // Ideal é salvar na EEPROM
}

int main(void)
{
	uint8_t aux8 = 0;
	MOTOR_DIR |= (1 << MOTOR_IN1) | (1 << MOTOR_IN2) |
		(1 << MOTOR_IN3) | (1 << MOTOR_IN4);
	MOTOR_EN_DIR |= (1 << MOTOR_ENA) | (1 << MOTOR_ENB);

	usart0.setBaudRate(Usart0::BaudRate::BAUD_RATE_57600);
	usart0.init();
	usart0.enableTransmitter();
	usart0.enableReceiver();
	usart0.activateReceptionCompleteInterrupt();
	usart0.stdio();
	printf("UART configured!\r\n");


    // Configurar PWM para controle de velocidade
	pwm_init();
	motor_left_speed(0);
	motor_right_speed(0);

    printf("=== Car Control System Started ===\r\n");
    // Inicializar SPI e NRF24L01
    spi_init();
    irq_init(); // Configurar a interrupção do IRQ
    const uint8_t rx_addr[5] = {'C', 'A', 'R', '1', 'A'};
    nrf_init_rx_irq(rx_addr);
	nrfRxCircBuffer.init(50);
    printf("NRF24L01 Initialized - RX Mode\r\n");
    printf("Waiting for commands...\r\n\n");


	sei();
// test_movements_simple();
	// MOTOR_OUT |= (1 << MOTOR_IN1) | (0 << MOTOR_IN2) |
	// 	(1 << MOTOR_IN3) | (0 << MOTOR_IN4);
	while (1) {

		if((!nrfRxCircBuffer.isEmpty()) && (gettingPackage)) {//não lembro do que arrumar aqui

			nrfRxCircBuffer.pop(&aux8);

			// GET PACKAGE FROM BUFFER
			switch (packageIndex) {
			case 0:					// INI
				if(aux8 == INIT){  //0x7E) {
					packageData[packageIndex++] = aux8;
				}
				break;
			case 1:					// TIPO
				// if ((aux8 == 0x40) || (aux8 == 0x3F)) {
				if ((aux8 == DATA) || (aux8 == CALIB)) {
					packageData[packageIndex++] = aux8;
				} else if(aux8 == INIT){  //0x7E) {
					packageData[0] = aux8;
				} else {
					packageIndex = 0;
				}
				break;
			case 2 ... 5:
				packageData[packageIndex++] = aux8;
				break;
			case 6 ... 7:
				if(packageData[1] == DATA){ //0x40) {
					if(aux8 != NOPC){//0x00) {
						packageIndex = 0;
						break;
					}
				}
				packageData[packageIndex++] = aux8;
				if(packageIndex == 8) {			// CPACKGE COMPLETED

					newPackageAwaiting = true;
					gettingPackage = false;

				}
				break;
			default:
				break;
			}
		} else if(!gettingPackage) {
			if(newPackageAwaiting) {
					printf("\r\r");

				if (packageData[1] == DATA) {
					printf("DATA\r");
					process_data_package(packageData);
				}else{
					printf("CALIB\r");
					process_calib_package(packageData);

				}
					for(uint8_t i = 2;i < 8;i++) {
						printf("%c ", packageData[i]);
					}
				// PROCESS PACKAGE
				packageIndex = 0;
				newPackageAwaiting = false;
			}
		}

		printf("CIRC=%u/%u %u %u %u\r", nrfRxCircBuffer.getOccupation(), nrfRxCircBuffer.getFreeSpace(), newPackageAwaiting, gettingPackage, packageIndex);
		delayMs(50);
	}
	return 0;
}

void usartReceptionCompleteCallback(void)
{
	nrfRxCircBuffer.push(UDR0); // SPDR (?)
}

// =============================================================================
// Interrupt Service Routines
// =============================================================================
// ISR para a interrupção de recepção do NRF24L01
ISR(INT0_vect) {
    uint8_t status;
    CSN_LOW();
    status = spi_tx(NOP); // Lê o registrador STATUS
    CSN_HIGH();

    // Verifica se há dados recebidos (RX_DR)
    if (status & 0x40) {
        uint8_t data[8];
        nrf_read_payload(data, 8); // Lê o payload de 8 bytes
        // Coloca cada byte no buffer circular
        for(uint8_t i = 0; i < 8; i++) {
            nrfRxCircBuffer.push(data[i]);
        }

        // Limpa a flag RX_DR
        nrf_write_reg(STATUS, 0x40);

        printf("IRQ: Received package\r\n");
    }

    // Limpa outras flags se necessário
    if (status & 0x10) { // MAX_RT
        nrf_write_reg(STATUS, 0x10);
        nrf_flush_tx();
        printf("IRQ: Max Retries\r\n");
    }
    if (status & 0x20) { // TX_DS
        nrf_write_reg(STATUS, 0x20);
        printf("IRQ: TX Success\r\n");
    }
}
