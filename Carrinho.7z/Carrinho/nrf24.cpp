
#include "nrf24.hpp"

// RX mode init IRQ
void nrf_init_rx_irq(const uint8_t *rx_addr)
{
    CE_LOW();
    _delay_ms(5);
    nrf_write_buf(RX_ADDR_P0, rx_addr, 5);
    nrf_write_reg(EN_AA, 0x00);
    nrf_write_reg(RF_CH, 76);
    nrf_write_reg(RF_SETUP, 0x06);
    nrf_write_reg(RX_PW_P0, 1);
    nrf_write_reg(CONFIG, 0b00001111); // PWR_UP + PRIM_RX + IRQ enabled
    nrf_flush_rx();
    CE_HIGH();
}
